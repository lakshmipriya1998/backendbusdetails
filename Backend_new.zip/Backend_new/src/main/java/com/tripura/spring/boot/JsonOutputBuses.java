package com.tripura.spring.boot;

import java.util.List;



public class JsonOutputBuses {
	private List<BusDetails> list;

	public List<BusDetails> getList() {
		return list;
	}

	public void setList(List<BusDetails> list) {
		this.list = list;
	}
	
	
	

}
